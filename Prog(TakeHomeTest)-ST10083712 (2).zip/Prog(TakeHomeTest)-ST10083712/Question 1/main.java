public class main {
public static void main(String[] args){
        //declare the 2-d array/
        int hos[][]={{4,8,6},{5,4,2},{4,2,8}};
        //declare 1-d array/
        double out[]=new double[3];
        //find total/
        for(int i=0;i<3;i++)
        {
            //nested loop/
            for(int j=0;j<3;j++)
            {
                //do sum/
                out[i]+=hos[i][j];
            }
        }

        System.out.println("*******");
        System.out.println("HEALTH INSPECTION REPORT");
        System.out.println("*******");
        //print header/
        System.out.println("    \t\t Jan\tFeb\tMarch\tAVG");
        //take a loop/
        for(int i=0;i<3;i++)
        {
           //print output/
            System.out.print("Hospital "+(i+1)+" : --> "+hos[i][0]+"\t"+hos[i][1]+"\t"+hos[i][2]);
            System.out.printf("\t%.2f\n",out[i]/3);
        }
        //print headers/
        System.out.println("*******");
        System.out.println("MONTHLY TOTALS");
        System.out.println("*******");
        //take a loop/
        for(int i=0;i<3;i++)
        {
            //print output/
            System.out.print("Hospital "+(i+1)+":");
            System.out.printf("\t%.1f\n",out[i]);
        }
        System.out.println("*******");
    
}
}

